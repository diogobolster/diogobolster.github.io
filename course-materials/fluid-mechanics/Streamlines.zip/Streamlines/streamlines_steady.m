%lines.m


clear
clc
close all

% x=linspace(-1,1,100);
% y=linspace(0,1,100);
% 
% [X,Y]=meshgrid(x,y);


%Draw streamlines at various times

count=1;

    t=0     %steady case - so t does not change
    N=5;    %number of particles

    x=linspace(-0.5,0.5,N);     %initial particle locations
    y=zeros(size(x));
    dt=0.01;                    %timestep

    figure(1)
%    subplot(2,2,count)
    plot(x,y,'.')
    hold on
    for ii=1:200

        xnew=x+UU(x,y,t)*dt;       %move particles with velocity field
        ynew=y+VV(x,y,t)*dt;

        x=xnew;y=ynew;
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
        
    end
    count=count+1;


figure(1)
title('Steady Streamlines');xlabel('x');ylabel('y')


