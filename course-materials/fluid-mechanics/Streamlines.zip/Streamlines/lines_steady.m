%lines.m


clear
clc
close all

% x=linspace(-1,1,100);
% y=linspace(0,1,100);
% 
% [X,Y]=meshgrid(x,y);


%Draw streamlines at various times

count=1;

    t=0     %steady case - so t does not change
    N=5;    %number of particles

    x=linspace(-0.5,0.5,N);     %initial particle locations
    y=zeros(size(x));
    dt=0.01;                    %timestep

    figure(1)
%    subplot(2,2,count)
    plot(x,y,'.')
    hold on
    for ii=1:200

        xnew=x+UU(x,y,t)*dt;       %move particles with velocity field
        ynew=y+VV(x,y,t)*dt;

        x=xnew;y=ynew;
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
        
    end
    count=count+1;


figure(1)
title('Steady Streamlines');xlabel('x');ylabel('y')


%Draw pathlineslines at various times

pause

x=linspace(-0.5,0.5,N);         %initial particle locations
y=zeros(size(x));
t=0;

figure(2)
hold on

for ii=1:200

        xnew=x+UU(x,y,t)*dt;        %update particle locations
        ynew=y+VV(x,y,t)*dt;

        x=xnew;y=ynew;
        figure(2)
        hold on
        pause(0.01)
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
%        t=t+dt;

end

pause

%Draw streaklines
    t=0;
    clear x y
    x=0;y=0;            %start with only one particle
    figure(3)
    hold off

    for ii=1:200

        xnew=x+UU(x,y,t)*dt;        %update position of all particles
        ynew=y+VV(x,y,t)*dt;

        x=[0 xnew];y=[0 ynew];      %add a new particle each timestep
 %       t=t+dt;
        figure(3)
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
        pause(0.01)
    end
    
    pause

%Draw streaklines from each of the starting points
for xx=linspace(-0.5,0.5,N);
    t=0;
    clear x y
    x=xx;y=0;
    figure(4)
    hold on

    for ii=1:200

        xnew=x+UU(x,y,t)*dt;
        ynew=y+VV(x,y,t)*dt;

        x=[xx xnew];y=[0 ynew];
  %      t=t+dt;
       
    end
     figure(4)
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
end