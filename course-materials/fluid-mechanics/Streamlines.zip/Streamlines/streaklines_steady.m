%lines.m


clear
clc
close all

count=1;

    t=0     %steady case - so t does not change
    N=5;    %number of particles

    dt=0.01;  
    x=0;y=0;            %start with only one particle
    figure(3)
    hold off

    for ii=1:200

        xnew=x+UU(x,y,t)*dt;        %update position of all particles
        ynew=y+VV(x,y,t)*dt;

        x=[0 xnew];y=[0 ynew];      %add a new particle each timestep
 %       t=t+dt;
        figure(3)
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
        pause(0.1)
    end
    
%     pause
% 
% %Draw streaklines from each of the starting points
% for xx=linspace(-0.5,0.5,N);
%     t=0;
%     clear x y
%     x=xx;y=0;
%     figure(4)
%     hold on
% 
%     for ii=1:200
% 
%         xnew=x+UU(x,y,t)*dt;
%         ynew=y+VV(x,y,t)*dt;
% 
%         x=[xx xnew];y=[0 ynew];
%   %      t=t+dt;
%        
%     end
%      figure(4)
%         plot(x,y,'.')
%         axis([-1.5 1.5 0 2])
% end