function [U]= UU(x,y,t)

%velocity in x direction

U=5*exp(-y).*cos(t-10*y);