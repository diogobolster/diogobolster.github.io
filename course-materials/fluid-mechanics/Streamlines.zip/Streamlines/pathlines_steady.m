%lines.m


clear
clc
close all


count=1;

    t=0     %steady case - so t does not change
    N=5;    %number of particles

    x=linspace(-0.5,0.5,N);     %initial particle locations
    y=zeros(size(x));
    dt=0.01;                    %timestep

figure(1)
hold on

for ii=1:200

        xnew=x+UU(x,y,t)*dt;        %update particle locations
        ynew=y+VV(x,y,t)*dt;

        x=xnew;y=ynew;
        figure(2)
        hold on
        pause(0.1)
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
%        t=t+dt;

end

