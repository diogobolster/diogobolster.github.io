%lines.m


clear
clc
close all

% x=linspace(-1,1,100);
% y=linspace(0,1,100);
% 
% [X,Y]=meshgrid(x,y);


%Draw streamlines at various times

count=1;

for t=[0 1 10 100];
    t
    N=5; %number of particles

    x=linspace(-0.5,0.5,N);
    y=zeros(size(x));
    dt=0.01;

    figure(1)
    subplot(2,2,count)
    plot(x,y,'.')
    hold on
    for ii=1:200

        xnew=x+UU(x,y,t)*dt;
        ynew=y+VV(x,y,t)*dt;

        x=xnew;y=ynew;
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
        
    end
    count=count+1;

end

figure(1)
subplot(2,2,1)
title('t=0');xlabel('x');ylabel('y')
subplot(2,2,2)
title('t=1');xlabel('x');ylabel('y')
subplot(2,2,3)
title('t=10');xlabel('x');ylabel('y')
subplot(2,2,4)
title('t=100');xlabel('x');ylabel('y')
%Draw pathlineslines at various times

pause

x=linspace(-0.5,0.5,N);
y=zeros(size(x));
t=0;

figure(2)
hold on

for ii=1:200

        xnew=x+UU(x,y,t)*dt;
        ynew=y+VV(x,y,t)*dt;

        x=xnew;y=ynew;
        figure(2)
        hold on
        pause(0.1)
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
        t=t+dt;

end

pause

%Draw streaklines
    t=0;
    clear x y
    x=0;y=0;
    figure(3)
    hold off

    for ii=1:200

        xnew=x+UU(x,y,t)*dt;
        ynew=y+VV(x,y,t)*dt;

        x=[0 xnew];y=[0 ynew];
        t=t+dt;
        figure(3)
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
        pause(0.1)
    end
    
    pause

%Draw streaklines
for xx=linspace(-0.5,0.5,N);
    t=0;
    clear x y
    x=xx;y=0;
    figure(4)
    hold on

    for ii=1:200

        xnew=x+UU(x,y,t)*dt;
        ynew=y+VV(x,y,t)*dt;

        x=[xx xnew];y=[0 ynew];
        t=t+dt;
       
    end
     figure(4)
        plot(x,y,'.')
        axis([-1.5 1.5 0 2])
end