function [V]= VV(x,y,t)

%velocity in y direction

V=1;