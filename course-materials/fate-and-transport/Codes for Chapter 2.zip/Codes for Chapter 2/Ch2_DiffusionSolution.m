%The solution to the diffusion equation

%I always start codes by clearing the memory and closing all figures
clear
clc
close all

%Create a domain spanning from x=-10 to 10, divided into 100 equal
%increments
x=linspace(-10,10,100);


%set the diffusion coefficient D and time t
D=1;
t=1;
C1=1/sqrt(1*pi*D*t).*exp(-x.^2/(4*D*t));

%plot the data 
figure(1)
plot(x,C1)
hold on   %writing this command allows us to plot multilpe graphs on the same figure

%set another diffusion coefficient D and time t
D=2;
t=1;
C2=1/sqrt(1*pi*D*t).*exp(-x.^2/(4*D*t));
plot(x,C2,'r')

%set another diffusion coefficient D and time t
D=1;
t=2;
C3=1/sqrt(1*pi*D*t).*exp(-x.^2/(4*D*t));
plot(x,C3,'g.')

%set another diffusion coefficient D and time t
D=2;
t=2;
C4=1/sqrt(1*pi*D*t).*exp(-x.^2/(4*D*t));
plot(x,C4,'m')


%Label the axes and create a legend
xlabel('x')
ylabel('y')
legend('D=1,t=1','D=2,t=1','D=1,t=2','D=2,t=2')
