%rw_distributions.m
clear
clc
close all

dt=1;  %time step
N=1e6;  %number of particles

x=zeros(1,N);  %initial condition - delta pulse at x=0
Nsteps=100;    %Number of time steps

xl=-50:2:50;

%random walk for normal distribution
for j=1:Nsteps
   x=x+randn(size(x));
end

%calculate and plot concentration
[C,xloc]=hist(x,xl);
M=sum(C*(xloc(2)-xloc(1)));
C=C/M;
plot(xloc,C)


%random walk for uniform distribution
x=zeros(1,N);
for j=1:Nsteps
   x=x+sqrt(12)*(rand(size(x))-0.5);
end
hold on
[C2,xloc]=hist(x,xl);
M=sum(C2*(xloc(2)-xloc(1)));
C2=C2/M;
plot(xloc,C2,'r')


%random walk for delat distribtion


x=zeros(1,N);
for j=1:Nsteps
   x=x+sign((rand(size(x))-0.5));
end
[C3,xloc]=hist(x,xl);
M=sum(C3*(xloc(2)-xloc(1)));
C3=C3/M;
plot(xloc,C3,'g')

%random walk for 2 sided exponential


x=zeros(1,N);
lambda=sqrt(2);

for j=1:Nsteps
   x=x-1/lambda*log(1-rand(1,N)).*sign(rand(1,N)-0.5);
end
[C4,xloc]=hist(x,xl);
M=sum(C4*(xloc(2)-xloc(1)));
C4=C4/M;
plot(xloc,C4,'k')

%random walk for 1 sided exponential

x=zeros(1,N);
lambda=1;

for j=1:Nsteps
   x=x+(-1/lambda*log(1-rand(1,N))-1);
end
[C4,xloc]=hist(x,xl);
M=sum(C4*(xloc(2)-xloc(1)));
C4=C4/M;
plot(xloc,C4,'c')

legend('Normal','Uniform','Delta','2 exp','1 exp')
xlabel('x')
ylabel('Concentration')
title('Concentration for different random walks at t=1')