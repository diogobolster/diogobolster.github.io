%rw_distributions.m
clear
clc
close all

dt=1;  %time step
N=1e6;  %number of particles

x=zeros(1,N);  %initial condition - delta pulse at x=0
Nsteps=100;    %Number of time steps

xl=-1000:1:1000;

%random walk for normal distribution
for j=1:Nsteps
   x=x+randn(size(x));
end

[C,xloc]=hist(x,xl);
M=sum(C*(xloc(2)-xloc(1)));
C=C/M;
hold on
plot(xloc,C,'b')

alpha=1.5;
x=zeros(1,N);
for j=1:Nsteps
   x=x+0.19*(1-rand(size(x))).^(-1/alpha).*sign(rand(1,N)-0.5);
end


%calculate and plot concentration
[C,xloc]=hist(x,xl);
M=sum(C*(xloc(2)-xloc(1)));
C=C/M;
hold on
plot(xloc,C,'r')


legend('Normal','Pareto \alpha=1.5')
xlabel('x')
ylabel('Concentration')
title('Concentration for different random walks at t=1')