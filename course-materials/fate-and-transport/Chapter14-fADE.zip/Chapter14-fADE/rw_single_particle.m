%rw_distributions.m
clear
clc
close all

dt=1;  %time step
N=1e1;  %number of particles

Nsteps=100;
t=1:Nsteps+1;
x=zeros(1,N);  %initial condition - delta pulse at x=0
                %Number of time steps
%random walk for normal distribution
for j=1:Nsteps
   x(j+1)=x(j)+randn;
end

plot(t,x,'b.')

xlabel('x')
ylabel('t')


alpha=1.5;
x=zeros(1,Nsteps);
for j=1:Nsteps
   x(j+1)=x(j)+0.19*(1-rand).^(-1/alpha).*sign(rand-0.5);
end

figure(2)
plot(t,x,'r.')
xlabel('x')
ylabel('t')