%HW1 - FT

%THe key to this problem is to recognize that the two functions given are
%inverse functions. That is the given f(k) is the Fourier transform of f(x)
%and vice versa so the comparison is easy.

clear
clc
close all

%Define our Domains in x and k

x=-100:0.1:100;  %this is domain that goes from x=-10 to 10 in increments of 0.01;
k=-100:0.01:100;  %same for Fourier domain


%Define the function we want to Inverse Fourier Transform
alpha=1.1
fk1=exp(((-i*k).^alpha+(i*k).^alpha));
alpha=1.3
fk3=exp(((-i*k).^alpha+(i*k).^alpha));
alpha=1.5
fk5=exp(((-i*k).^alpha+(i*k).^alpha));
alpha=1.7
fk7=exp(((-i*k).^alpha+(i*k).^alpha));
alpha=1.9
fk9=exp(((-i*k).^alpha+(i*k).^alpha));

dk=k(2)-k(1)       %spatial step

for jj=1:length(x)
   
    Fx1(jj)=1/2/pi*sum(fk1.*exp(-i*k*x(jj)))*dk;
    Fx3(jj)=1/2/pi*sum(fk3.*exp(-i*k*x(jj)))*dk;
    Fx5(jj)=1/2/pi*sum(fk5.*exp(-i*k*x(jj)))*dk;
    Fx7(jj)=1/2/pi*sum(fk7.*exp(-i*k*x(jj)))*dk;
    Fx9(jj)=1/2/pi*sum(fk9.*exp(-i*k*x(jj)))*dk;
    
end

figure(2)
hold on
%plot(x,fx,'.')
plot(x,Fx1,'k')
plot(x,Fx3,'b')
plot(x,Fx5,'r')
plot(x,Fx7,'g')
plot(x,Fx9,'m')
xlabel('x')
ylabel('f(x)')
axis([-10 10 0 1])
%legend('Analytical','Numerical')
title('Inverse Fourier Trasform of f(k)')

