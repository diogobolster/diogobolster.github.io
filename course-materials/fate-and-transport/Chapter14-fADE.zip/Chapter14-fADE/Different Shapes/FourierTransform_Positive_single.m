%HW1 - FT

%THe key to this problem is to recognize that the two functions given are
%inverse functions. That is the given f(k) is the Fourier transform of f(x)
%and vice versa so the comparison is easy.

clear
clc
close all

%Define our Domains in x and k

x=-100:0.1:100;  %this is domain that goes from x=-10 to 10 in increments of 0.01;
k=-100:0.01:100;  %same for Fourier domain


%Define the function we want to Inverse Fourier Transform
alpha=1.5
fk=exp(((-i*k).^alpha));


dk=k(2)-k(1)       %spatial step

for jj=1:length(x)
   
    Fx(jj)=1/2/pi*sum(fk.*exp(-i*k*x(jj)))*dk;
    
end

figure(1)
hold on
%plot(x,fx,'.')
plot(x,Fx,'k')
plot(x,1/sqrt(4*pi)*exp(-x.^2/4));
xlabel('x')
ylabel('f(x)')
axis([-10 10 0 1])
%legend('Analytical','Numerical')
title('Inverse Fourier Trasform of f(k)')

figure(2)
hold on
%plot(x,fx,'.')
plot(x,Fx,'k')
plot(x,1/sqrt(4*pi)*exp(-x.^2/4));

xlabel('x')
ylabel('f(x)')
axis([-10 10 0 1])
%legend('Analytical','Numerical')
title('Inverse Fourier Trasform of f(k)')
set(gca,'Xscale','linear','Yscale','log')
axis([-100 100 1e-7 1])
