%pareto.m

clear
clc
close all

chi=1;

x=linspace(1,10);

alpha=2;
p=alpha*x.^(-alpha-1);
plot(x,p)
hold on

alpha=1.5;
p=alpha*x.^(-alpha-1);
plot(x,p,'r')

alpha=1;
p=alpha*x.^(-alpha-1);
plot(x,p,'k')

alpha=0.5;
p=alpha*x.^(-alpha-1);
plot(x,p,'g')


xlabel('x')
ylabel('p(x)')

legend('\alpha=2','\alpha=1.5','\alpha=1','\alpha=0.5')

figure(2)

x=logspace(-1,4,1000);

alpha=2;
p=alpha*x.^(-alpha-1);
plot(x,p)
hold on

alpha=1.5;
p=alpha*x.^(-alpha-1);
plot(x,p,'r')

alpha=1;
p=alpha*x.^(-alpha-1);
plot(x,p,'k')

alpha=0.5;
p=alpha*x.^(-alpha-1);
plot(x,p,'g')


xlabel('x')
ylabel('p(x)')

legend('\alpha=2','\alpha=1.5','\alpha=1','\alpha=0.5')
set(gca,'Xscale','log','Yscale','log')
