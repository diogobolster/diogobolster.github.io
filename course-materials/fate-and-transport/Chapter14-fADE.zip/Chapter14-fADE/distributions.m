%distributions.m

clear
clc
close all


dx=0.01;
x=-10:dx:10;

normal=1/sqrt(2*pi).*exp(-x.^2/2);

uniform=1/2/sqrt(3)*ones(size(x)); 
apple=find(x<-sqrt(3)); uniform(apple)=0;apple=find(x>sqrt(3)); uniform(apple)=0;

delta=zeros(size(x));
apple=find(x==-1);delta(apple)=1/2/dx;apple=find(x==1);delta(apple)=1/2/dx;

exp2=sqrt(2)/2*exp(-sqrt(2)*abs(x));

exp1=exp(-(x+1));
apple=find(x<-1);exp1(apple)=0;


figure(1)
subplot(2,3,1)
plot(x,normal)
xlabel('x');ylabel('p(x)');title('Normal')
subplot(2,3,2)
plot(x,uniform)
xlabel('x');ylabel('p(x)');title('Uniform')
subplot(2,3,3)
plot(x,delta)
xlabel('x');ylabel('p(x)');title('Delta')
axis([-10 10 0 55])
subplot(2,3,4)
plot(x,exp2)
xlabel('x');ylabel('p(x)');title('2 sided Exponential')
subplot(2,3,5)
plot(x,exp1)
xlabel('x');ylabel('p(x)');title('1 sided Exponential')