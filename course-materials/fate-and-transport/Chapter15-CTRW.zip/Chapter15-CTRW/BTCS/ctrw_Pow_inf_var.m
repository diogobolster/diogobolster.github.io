clear
clc
%close all


%mean of an exponential distribution
alpha=1.5

%measure concentration distribtion at time t=10;

Npart=1e6;

Nsteps=100;

for kk=1:Npart

     %generate Nsteps random times from distribution   
    tau=(1./(1-rand(1,Nsteps))).^(1/alpha)*(alpha-1)/alpha;

    
     time(kk)=sum(tau);
    
end

%A few different Intepretatios of the Data

%Particles wait an then instantaneously jump to new position after a
%waiting time tau. Then the position of all particles xold describes their
%position at time 10

figure(1)
tplot=logspace(-1,4);
[c,x]=hist(time,tplot)



        


