clear
clc
%close all


%mean of an exponential distribution
alpha=0.8

%measure concentration distribtion at time t=10;

Npart=1e6;

Nsteps=100;

for kk=1:Npart

     %generate Nsteps random times from distribution   
    tau=(1./(1-rand(1,Nsteps))).^(1/alpha);

    
     time(kk)=sum(tau);
    
end

%A few different Intepretatios of the Data

%Particles wait an then instantaneously jump to new position after a
%waiting time tau. Then the position of all particles xold describes their
%position at time 10

figure(1)
tplot=logspace(-1,10,1000);
[c,x]=hist(time,tplot);
plot(x,c)

apple=find((log(c)>0))
lx=x(apple);
lc=c(apple);
        


