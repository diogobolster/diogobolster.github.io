clear
clc
%close all


%mean of an exponential distribution
lambda=1;

Time=100; %Time at which we want to know particles positions

%measure concentration distribtion at time t=10;

Npart=1e6;

Nsteps=100;

for kk=1:Npart

     %generate Nsteps random times from distribution   
     tau=-1/lambda.*log(1-rand(1,Nsteps));
    
     time(kk)=sum(tau);
    
end

%A few different Intepretatios of the Data

%Particles wait an then instantaneously jump to new position after a
%waiting time tau. Then the position of all particles xold describes their
%position at time 10

figure(1)
hist(time,100)


