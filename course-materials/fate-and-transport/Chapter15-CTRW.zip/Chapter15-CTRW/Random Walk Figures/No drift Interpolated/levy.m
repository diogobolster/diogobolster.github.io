%levy.m

clear
clc
close all

steps=100;
x=zeros(1,steps);
t=0:1:steps;
alpha=1.5;

for kk=1:steps
    
    x(kk+1)=x(kk)+(1-rand)^(-1/alpha)*0.1*sign(rand-0.5);
    
end

tplot=0;
xplot=0;

for kk=1:steps
   
    tplot=[tplot kk kk];
    xplot=[xplot x(kk) x(kk+1)];
end

figure(1)
%plot(t,x)
hold on
plot(t,x,'r')

xlabel('time')
ylabel('x')



figure(2)
hold on
xlabel('time')
ylabel('x')

for ll=1:500
    ll
    for kk=1:steps
    
        x(kk+1)=x(kk)+(1-rand)^(-1/alpha)*0.1*sign(rand-0.5);
    
    end

    tplot=0;
    xplot=0;

    for kk=1:steps
   
        tplot=[tplot kk kk];
        xplot=[xplot x(kk) x(kk+1)];
    end

    figure(2)
    plot(t,x)
end
