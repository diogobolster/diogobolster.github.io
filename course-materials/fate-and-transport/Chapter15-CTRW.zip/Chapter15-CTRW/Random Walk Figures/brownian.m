%brownian.m

clear
clc
close all

steps=100;
x=zeros(1,steps);
t=0:1:steps;


for kk=1:steps
    
    x(kk+1)=x(kk)+randn;
    
end

tplot=0;
xplot=0;

for kk=1:steps
   
    tplot=[tplot kk kk];
    xplot=[xplot x(kk) x(kk+1)];
end

figure(1)
%plot(t,x)
hold on
plot(tplot,xplot,'r')

xlabel('time')
ylabel('x')

figure(2)
hold on
xlabel('time')
ylabel('x')

for ll=1:500
    ll
    for kk=1:steps
    
        x(kk+1)=x(kk)+randn;
    
    end

    tplot=0;
    xplot=0;

    for kk=1:steps
   
        tplot=[tplot kk kk];
        xplot=[xplot x(kk) x(kk+1)];
    end

    figure(2)
    plot(tplot,xplot)
end
