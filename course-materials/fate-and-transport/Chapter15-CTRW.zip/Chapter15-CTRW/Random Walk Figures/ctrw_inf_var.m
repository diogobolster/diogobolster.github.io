%ctrw.m

clear
clc
close all

steps=100;
x=zeros(1,steps);
t=zeros(1,steps);
alpha=1.5;

for kk=1:steps
    
    x(kk+1)=x(kk)+sign(rand-0.5);
    t(kk+1)=t(kk)+(1-rand)^(-1/alpha)*(alpha-1)/alpha;
end

tplot=0;
xplot=0;

for kk=1:steps
   
    tplot=[tplot t(kk) t(kk)];
    xplot=[xplot x(kk) x(kk+1)];
end

figure(1)
%plot(t,x)
hold on
plot(tplot,xplot,'r')

xlabel('time')
ylabel('x')



figure(2)
hold on
xlabel('time')
ylabel('x')

for ll=1:1000
    ll
    for kk=1:steps
    
        x(kk+1)=x(kk)+sign(rand-0.5);
        t(kk+1)=t(kk)+(1-rand)^(-1/alpha)*(alpha-1)/alpha;
    
    end

    tplot=0;
    xplot=0;

    for kk=1:steps
   
        tplot=[tplot t(kk) t(kk)];
        xplot=[xplot x(kk) x(kk+1)];
    end

    figure(2)
    plot(tplot,xplot)
end
