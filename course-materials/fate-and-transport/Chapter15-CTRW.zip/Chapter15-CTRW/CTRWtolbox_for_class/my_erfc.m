function y = my_erfc(x)
% ------------------------------------------------------------
% MY_ERFC
% Matlab Complementary error function ERFC 
% modified to accept a vector input.
%
% Type 'help erfc' for the usage of this function
% ------------------------------------------------------------

% This file is part of the CTRW toolbox v3.0
% For the usage of this file see Legal_notice.m
% Author   : Andrea Cortis
% $Original version : 26-Jun-2004$
% e-mail   : brian.berkowitz@weizmann.ac.il
%           (see http://weizmann.ac.il/ESER/people/Brian/CTRW)

% ------------------------------------------------------------

if isreal(x)
    siz = size(x);
    x = x(:);
    y = reshape(erfcore(x,1), siz);
else
    warning('X must be real.'); 
    siz = size(x);
    x = x(:);
    y = reshape(NaN*x, siz);
end
