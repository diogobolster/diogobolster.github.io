function [err , model] = diff_norm_lim_b(varpar,tipo)
% DIFF_NORM_LIM_B
% Computes the norm of the difference between two vectors
% Given tha data         : t = data(:,1) , y = data(:,2).
% and the model function : function(t,param,funpar)
% 
% [ERR,MODEL] = DIFF_NORM_LIM_B(VARPAR,TIPO)
% 
% varpar := first  argument of the model function
% tipo   := second argument of the model function
% err    := norm of the difference between the vectors 
%           (or the log of the vectors)
% model  := value of the model function at the data points
% 
% Example: 
% data = [
%   147.5367    0.0264
%   152.8100    0.0709
%   156.1133    0.1124
%   159.4117    0.1554
%   186.7333    0.7627
%   236.9167    0.9742
  %   ];
% options = {'TPL','N','step','c_f_norm',1,1,'R'};
% v =  [1e-3] ;             
% D = [2e-5] ;
% p= [1.3 -1.9 5.85];
% vDp = [v D p];
%  con(1:2) = vDp(1:2);
%  var(1) = vDp(3);
%  con(3:4)    = vDp(4:5);
% [err  model] = diff_norm_lim_b(var,{con,data,'t_conc',options})
% ------------------------------------------------------------

% This file is part of the CTRW toolbox v3.1
% For the usage of this file see Legal_notice.m
% Author   : Andrea Cortis
% $Original version : 26-Jun-2004$
% Modified by: Simon Emmanuel
% $Modified version : 27-Nov-2006$
% Modified by: Shira Rubin
% $Modified version : May-2010$
% e-mail   : brian.berkowitz@weizmann.ac.il
%           (see http://weizmann.ac.il/ESER/people/Brian/CTRW)

% ------------------------------------------------------------

con = tipo{1};
data     = tipo{2}; 
funzione = tipo{3};
options = tipo{4};

varpar_new(1:2) = con(1:2); 
varpar_new(3) = varpar(1); 
varpar_new(4:5) = con(3:4); 

com = strcat(funzione,'(data(:,1), varpar_new, options)');
 
if (varpar_new(1)>0 & varpar_new(2)>0)
    model = eval(com);
    err = sum([norm(model(:,1) - data(:,2) )]);
 else
    model = NaN*ones(size(data(:,1)));
    err = NaN;
end
   
fprintf(1,'difference = %6.4e \n',err);