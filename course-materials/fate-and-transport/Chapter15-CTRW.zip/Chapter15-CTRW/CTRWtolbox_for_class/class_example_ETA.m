%Class_example_1.m

clear; clc; close all
v =  0.067 ; % v_psi  [T^-1]             
D = 1.1e-2 ;% D_psi  [T^-1] 
t=1:0.1:100; t=t';
p=[0.5];
options = { 'ETA','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y)
p=[1];
options = { 'ETA','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y,'r')
p=[1.5];
options = { 'ETA','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y,'k')
xlabel('time')
ylabel('Conc')




%set(gca,'Xscale','log','Yscale','log')
