function gen_output(vDp_old, vDp, err_old, err, mod_type, output);     

% This file is part of the CTRW toolbox v3.0
% For the usage of this file see Legal_notice.m
% Author   : Andrea Cortis
% $Original version : 26-Jun-2004$
% Modified by: Simon Emmanuel
% $Modified version : 27-Nov-2006$
% e-mail   : brian.berkowitz@weizmann.ac.il
%           (see http://weizmann.ac.il/ESER/people/Brian/CTRW)

LL='L';
TT='T';
LT = 'log10(T)';
TFDE = 'T^(1+Beta)';

LE = length(vDp);
fid = fopen(output,'w');

if LE == 2
fprintf(fid,'v(initial) : %6.4e [%s/%s]   \n', vDp_old(1), LL, TT);
fprintf(fid,'D(initial) : %6.4e  [%s^2/%s]         \n',vDp_old(2) , LL, TT);
fprintf(fid,'v(final) : %6.4e [%s/%s]   \n', vDp(1), LL, TT);
fprintf(fid,'D(final) : %6.4e  [%s^2/%s]         \n',vDp(2) , LL, TT);
end

if LE == 3 & mod_type == ['ETA']
fprintf(fid,'v(initial) : %6.4e [%s/%s]   \n', vDp_old(1), LL, TT);
fprintf(fid,'D(initial) : %6.4e  [%s^2/%s]         \n',vDp_old(2) , LL, TT);
fprintf(fid,'Eta(initial) : %6.4e         \n',vDp_old(3) ); 
fprintf(fid,'v(final) : %6.4e [%s/%s]   \n', vDp(1), LL, TT);
fprintf(fid,'D(final) : %6.4e  [%s^2/%s]         \n',vDp(2) , LL, TT);
fprintf(fid,'Eta(final) : %6.4e         \n',vDp(3) ); 
end

if LE == 3 & mod_type == ['FDE']
fprintf(fid,'v(initial) : %6.4e [%s/%s]   \n', vDp_old(1), LL, TFDE);
fprintf(fid,'D(initial) : %6.4e  [%s^2/%s]         \n',vDp_old(2) , LL, TFDE);
fprintf(fid,'Beta(initial) : %6.4e         \n',vDp_old(3) ); 
fprintf(fid,'v(final) : %6.4e [%s/%s]   \n', vDp(1), LL, TFDE);
fprintf(fid,'D(final) : %6.4e  [%s^2/%s]         \n',vDp(2) , LL, TFDE);
fprintf(fid,'Beta(final) : %6.4e         \n',vDp(3) ); 
end

if LE == 5 & mod_type == ['TPL']
fprintf(fid,'v(initial) : %6.4e [%s/%s]   \n', vDp_old(1), LL, TT);
fprintf(fid,'D(initial) : %6.4e  [%s^2/%s]         \n',vDp_old(2) , LL, TT);
fprintf(fid,'Beta(initial) : %6.4e         \n',vDp_old(3) ); 
fprintf(fid,'log10(t1)(initial): %6.4e  [%s]         \n',vDp_old(4), LT );
fprintf(fid,'log10(t2)(initial): %6.4e  [%s]         \n',vDp_old(5), LT );
fprintf(fid,'v(final) : %6.4e [%s/%s]   \n', vDp(1), LL, TT);
fprintf(fid,'D(final) : %6.4e  [%s^2/%s]         \n',vDp(2) , LL, TT);
fprintf(fid,'Beta(final) : %6.4e         \n',vDp(3) ); 
fprintf(fid,'log10(t1)(final): %6.4e  [%s]         \n',vDp(4), LT );
fprintf(fid,'log10(t2)(final): %6.4e  [%s]         \n',vDp(5), LT );
end

if LE == 5 & mod_type == ['ASY']
fprintf(fid,'v(initial) : %6.4e [%s/%s]   \n', vDp_old(1), LL, TT);
fprintf(fid,'D(initial) : %6.4e  [%s^2/%s]         \n',vDp_old(2) , LL, TT);
fprintf(fid,'Beta(initial) : %6.4e         \n',vDp_old(3) ); 
fprintf(fid,'a(initial): %6.4e  [%s]         \n',vDp_old(4), LT );
fprintf(fid,'b(initial): %6.4e  [%s]         \n',vDp_old(5), LT );
fprintf(fid,'v(final) : %6.4e [%s/%s]   \n', vDp(1), LL, TT);
fprintf(fid,'D(final) : %6.4e  [%s^2/%s]         \n',vDp(2) , LL, TT);
fprintf(fid,'Beta(final) : %6.4e         \n',vDp(3) ); 
fprintf(fid,'a(final): %6.4e  [%s]         \n',vDp(4), LT );
fprintf(fid,'b(final): %6.4e  [%s]         \n',vDp(5), LT );
end

fprintf(fid,'error(initial) : %6.4e          \n', err_old );
fprintf(fid,'error(final) : %6.4e          \n', err );
fclose(fid);