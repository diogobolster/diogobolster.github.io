% Example data for modeling sorption/desorption in input_6.m

a = [0 7e-8
    0.09 0.2e-4
    0.2 0.03
    0.5 0.6
    1 0.9
    1.3 0.7
    2 0.06
    3 8e-3
    10 2e-3
    20 6e-4
    30 4e-4
    100 1e-4
];