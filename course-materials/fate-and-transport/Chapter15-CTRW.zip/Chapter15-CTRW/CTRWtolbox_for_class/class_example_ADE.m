%Class_example_1.m

clear
clc
close all

v =  0.067 ; % v_psi  [T^-1]             
D = 1.1e-2 ;% D_psi  [T^-1] 

t=1:1:100;
t=t';
p=[];
options = { 'ADE','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
plot(t,y)

xlabel('time')
ylabel('Conc')




