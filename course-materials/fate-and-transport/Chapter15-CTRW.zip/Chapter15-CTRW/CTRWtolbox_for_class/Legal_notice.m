%
% ---------------- L E G A L   N O T I C E -----------------------------------------
%
% The "CTRW software" and the  "CTRW MATLAB toolbox" are produced by Brian Berkowitz, 
% Weizmann Institute of Science.
% Permission to use "CTRW software" is hereby granted to non-profit educational
% and research institutions, for educational and research purposes only, provided
% and as long this Notice appears.
% Distribution of this package in whole or in part, in its current or in any  
% modified form, is strictly forbidden.
%
% THE CTRW SOFTWARE IS BEING DEVELOPED AS A TOOL FOR SCIENTIFIC RESEARCH.
% HENCE IT IS NOT PRESENTED AS ERROR FREE, ACCURATE, COMPLETE, OR USEFUL FOR
% ANY SPECIFIC APPLICATION, AND THE WEIZMANN INSTITUTE MAKES NO WARRANTY OR
% REPRESENTATION THERETO.
%
% THE WEIZMANN INSTITUTE SHALL NOT BE LIABLE FOR ANY CLAIMS, DEMANDS, LIABILITIES,
% COSTS, LOSSES, DAMAGES OR EXPENSE OF WHATSOEVER KIND OR NATURE CAUSED TO OR
% SUFFERED BY ANY PERSON OR ENTITY THAT DIRECTLY OR INDIRECTLY ARISE OUT OR
% RESULT FROM THE USE OF THE CTRW SOFTWARE OR IN CONNECTION THEREOF.
% 
% Trademarks appear throughout this toolbox and documentation 
% without any trademark symbol; they are the property
% of their trademark owner. There is no intention of infringement; 
% the usage is to the benefit of the trademark owner.
%
% For usage by and for commercial entities please contact Brian Berkowitz.
%
% If you publish work benefiting from this toolbox, please cite it as:
%
% Andrea Cortis, Simon Emmanuel, Shira Rubin, Karen Willbrand and Brian Berkowitz 
% The CTRW Matlab toolbox v3.0: a practical user's guide
% http://www.weizmann.ac.il/ESER/People/Brian/CTRW
% or using [Cortis, A. and B. Berkowitz (2005). Computing "anomalous" contaminant 
% transport in porous media: The CTRW MATLAB toolbox, Ground Water, 43(6), 947-950.] 
% ----------------------------------------------------------------------------------
