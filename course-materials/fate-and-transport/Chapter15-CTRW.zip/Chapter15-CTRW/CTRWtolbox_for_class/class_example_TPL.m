%Class_example_1.m

clear
clc
close all

v =  0.067 ; % v_psi  [T^-1]             
D = 1.1e-2 ;% D_psi  [T^-1] 


t=logspace(1,5);
t=t';


p=[1.5 -4 3];
options = { 'TPL','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y)

p=[1.5 -4 4];
options = { 'TPL','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y,'r')

p=[1.5 -4 6];
options = { 'TPL','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y,'k')

figure(2)

p=[1.5 0 3];
options = { 'TPL','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y,'--')

p=[1.5 0 4];
options = { 'TPL','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y,'r--')

p=[1.5 0 6];
options = { 'TPL','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
plot(t,y,'k--')


figure(1)
set(gca,'Xscale','log','Yscale','log')
axis([1e1 1e5 1e-15 1e0])
title('\beta=1.5,t_1=1e-4')
legend('t_2=1e3','t_2=1e4','t_2=1e6')

figure(2)
set(gca,'Xscale','log','Yscale','log')
axis([1e1 1e5 1e-15 1e0])
title('\beta=1.5,t_1=1e0')
legend('t_2=1e3','t_2=1e4','t_2=1e6')