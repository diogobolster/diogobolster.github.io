%Class_example_1.m

clear
clc
close all

v =  0.0067 ; % v_psi  [T^-1]             
D = 1.1e-4 ;% D_psi  [T^-1] 


t=logspace(2,7,100);
t=t';


p=[1.75 -1 5];
options = { 'TPL','N','pulse','c_f_norm',1,1,'D'};
y=t_conc(t,[v D p],options)
hold on
%plot(t,y)


figure(1)
%set(gca,'Xscale','log','Yscale','log')
%axis([0 300 0 1e0])
%title('\beta=1.5,t_1=1e-4')
%legend('t_2=1e3','t_2=1e4','t_2=1e6')

y_data=y.*(1+0.5*randn(size(y)));
hold on
plot(t,y_data,'r.','Markersize',12)
set(gca,'Xscale','log','Yscale','log')
a(1:100,:)=t;
a(1:100,2)=y_data;

save data_hw4.mat a