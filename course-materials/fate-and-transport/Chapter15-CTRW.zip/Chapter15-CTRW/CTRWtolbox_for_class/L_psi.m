function res = L_psi(u,param,funpar)
% ------------------------------------------------------------
% L_PSI
% Calculates the Laplace transform of the $\psi(t)$ function
% for the different models ADE, TPL, ASY, FDE, ETA. 
% 
% RES = L_PSI(U,PARAM,FUNPAR)
%
% u     := Laplace variable
% param := parameters of the psi function
% funpar:= string specifying the model
% res   := values of the function $\psi(t)$
% 
% Usage example:
% y = L_psi(1+i,[0.75 1 0.1],{'ASY'})
%
% See also T_PSI
% ------------------------------------------------------------

% This file is part of the CTRW toolbox v3.0
% For the usage of this file see Legal_notice.m
% Author   : Andrea Cortis
% $Original version : 26-Jun-2004$
% Modified by: Simon Emmanuel
% $Modified version : 27-Nov-2006$
% e-mail   : brian.berkowitz@weizmann.ac.il
%           (see http://weizmann.ac.il/ESER/people/Brian/CTRW)

% ------------------------------------------------------------
str_psi = funpar{1};
switch str_psi
    %------------------------------------------------------------------------
case {'ADE'}
%     %------------------------------------------------------------------------    
    tbar=1; % the exponential psi of the ADE model is not used directly 
    res = 1./(1+tbar*u);   
    
    % -----------------------------------------------------------------------
case {'TPL'}
    % -----------------------------------------------------------------------
    bexp = param(1);  
    t1   = param(2); t1 = 10^(t1);
    t2   = param(3); t2 = 10^(t2);
    e    = t1/t2;
    res  = (1+t2*u).^bexp.*exp(t1*u).*gammq(-bexp,e+t1*u)./gammq(-bexp,e);        
    % -----------------------------------------------------------------------
case {'ASY'}
    % -----------------------------------------------------------------------    
    bexp  = param(1);  
    a     = param(2);
    b     = param(3);    
    gamma = exp((log(-a/b))/(bexp-1));
    if bexp>1
        c = 10^round(log10(1/gamma));
    else
        c = 0;
    end
    res   = 1./(1 + a*u + b*u.^bexp + c*u.^2);                     
    % -----------------------------------------------------------------------
case {'FDE'}
    % -----------------------------------------------------------------------
    bexp = param(1); 
    res  = 1./(1+u.^bexp);        
    % -----------------------------------------------------------------------
case {'ETA'}
    % -----------------------------------------------------------------------
    eta = param(1); 
    res =  qis(eta,u,{'ETA'});    
    % -----------------------------------------------------------------------    
 otherwise
    res=eval(str_psi);
    % ---------------------------------------------------------------------
    % --    
% otherwise
%     fprintf(' Variable str_psi is: %s \n',str_mem);    
%     fprintf(' ERROR: valid options for variable "str_mem" are: \n')
%     fprintf('       "ADE", "FDE", "ASY", "TPL" and "ETA". \n')
%     error('STOP')
    % -----------------------------------------------------------------------
end    