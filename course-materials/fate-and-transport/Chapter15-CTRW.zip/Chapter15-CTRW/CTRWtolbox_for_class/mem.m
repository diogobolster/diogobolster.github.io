function res = mem(csi,param,options)
% ------------------------------------------------------------
% MEM
% Laplace transformed memory function $\tilde{M}(csi)$
% for the different models ADE, TPL, ASY, FDE, ETA. 
% 
% RES = MEM(CSI,PARAM,OPTIONS)
%
% csi     := Laplace variable
% param := parameters of the psi function
% options:= cell array
% res   := values of the function $\tilde(M)(csi)$
% 
% Usage example:
% y = MEM(1+i,[1 0.05 0.75],{'TPL', 'N', 'step', 'c_f_norm', 1, 1, 'R'})
%
% See also L_PSI, QIS
% ------------------------------------------------------------

% This file is part of the CTRW toolbox v3.1
% For the usage of this file see Legal_notice.m
% Author   : Andrea Cortis
% $Original version : 26-Jun-2004$
% Modified by: Simon Emmanuel
% $Modified version : 27-Nov-2006$
% Modified by: Shira Rubin
% $Modified version : May-2010$
% e-mail   : brian.berkowitz@weizmann.ac.il
%           (see http://weizmann.ac.il/ESER/people/Brian/CTRW)

% ------------------------------------------------------------
if length(options)>=8  % Sorption/desorption model
    sorption=1;
    lambda=options{8}(1);
    tau=options{8}(2);
    W=options{8}(3);
    phi=W*L_psi(csi,options{10},options(9))+(1-W)./csi/tau;
    nu=csi+lambda*(1-phi);
    csi1=nu; % csi1 is the input Laplace variable for L_psi
else
    csi1=csi;
    sorption=0;
end

str_mem = options{1};

switch str_mem
    % -----------------------------------------------------------------------
case 'ADE'
    % ----------------------------------------------------------------------- 
    if sorption==1
        tbar = 1;
        psi  = L_psi(csi1,[],{'ADE'});
        res  = tbar*psi/(1-psi)*csi;
    else
        res=1;
    end
    % -----------------------------------------------------------------------
case 'FDE'
    % -----------------------------------------------------------------------
    bexp  = param(1);      
    if (bexp>0 && bexp<1)
        psi  = L_psi(csi1,bexp,{'FDE'}); 
        tbar = 1;
        res  = tbar*psi/(1-psi)*csi;
    else
        res  = NaN;
    end        
    % -----------------------------------------------------------------------
case 'TPL'
    % -----------------------------------------------------------------------
beta     = param(1); 
t1            = param(2);          t1 = 10^(t1);
tbar =t1;
t2            = param(3);          t2 = 10^(t2);
mu = t1 .* csi1;    
tau2 = t2 ./ t1;
xf =  1 ./ tau2 + mu;

if xf <= 1
e    = t1/t2;
psi = (1+t2*csi1).^beta.*exp(t1*csi1).*gammq(-beta,e+t1*csi1)./gammq(-beta,e);
else 
nf = (  tau2.^(-beta) .* exp(tau2.^(-1)) .* gammq(-beta, tau2.^(-1))  ).^(-1);
lag_n = 8;
[t, w] = lagzo(lag_n);
for j = 1:lag_n
 ftj = (1 + t(j)./ xf)^( -1 - beta);  
lagint(j) = w(j) .* ftj;
end
totlagint = sum(lagint);
psi = nf ./xf .*  totlagint;
end
if t2>t1
        res = tbar*psi/(1-psi)*csi;
else
        res = NaN;
end 
if beta<0; res = NaN; end
if t1<0  ; res = NaN; end
if t2<0  ; res = NaN; end    
    % -----------------------------------------------------------------------
case 'ASY'
    % -----------------------------------------------------------------------
    bexp  = param(1);  
    a     = param(2);
    b     = param(3);    
    psi   = L_psi(csi1,[bexp a b],{'ASY'}); 
    tbar  = a;    
    if (bexp>0 && bexp<2)
        res = tbar*psi/(1-psi)*csi;
    else
        res = NaN;
    end    
    % -----------------------------------------------------------------------
case 'ETA'
    % -----------------------------------------------------------------------
    eta=param(1);
    load N
    load median_N
    tbar = interp1(N,median_N,eta); % median time
    eta = param(1);  
    psi = qis(eta,csi1,{'ETA'});
    res = tbar*psi/(1-psi)*csi;    
    % -----------------------------------------------------------------------
    otherwise
         tbar =param(1); % median time
         psi  = L_psi(csi1,[],{str_mem});
         res  = tbar*psi/(1-psi)*csi;

%     fprintf(' Variable str_mem is: %s \n',str_mem);
%     fprintf(' ERROR: valid options for variable "str_mem" are: \n')
%     fprintf('       "ADE", "FDE", "ASY", "TPL" and "ETA". \n')
%     error('STOP')
%     % -----------------------------------------------------------------------
end    