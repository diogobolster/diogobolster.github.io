clear
clc
%close all


%mean of an exponential distribution
lambda=1;

Time=100; %Time at which we want to know particles positions

%measure concentration distribtion at time t=10;

Npart=1e6;
Nsteps=zeros(1,Npart);
x=Nsteps;
xold=Nsteps;
xnew=Nsteps;
told=Nsteps;
tnew=Nsteps;

for kk=1:Npart

    t=0;
    
    while t<Time
       
        told(kk)=t;
        
        tau=-1/lambda*log(1-rand);
        
        tnew(kk)=told(kk)+tau;
        dtau(kk)=tau;
        t=tnew(kk);
        
        Nsteps(kk)=Nsteps(kk)+1;
        
        xold(kk)=x(kk);
        xnew(kk)=x(kk)+1;
        x(kk)=xnew(kk);
    end
    
    
    
end

%A few different Intepretatios of the Data

%Particles wait an then instantaneously jump to new position after a
%waiting time tau. Then the position of all particles xold describes their
%position at time 10

figure(1)
hist(xold,100)


%Particles move at a sonstant velocity during a given jump between their
%starting and end poit. This velocity depends on the size of tau - i.e.
%L/tau;

frac=(Time-told)./dtau;

figure(2)
xinterp=xold+(xnew-xold).*frac;
hist(xinterp,100)

