clear
clc
%close all


%mean of an exponential distribution
alpha=1.5;


Time1=10; %Time at which we want to know particles positions
Time2=100; %Time at which we want to know particles positions
Time3=1000; %Time at which we want to know particles positions
Time4=10000; %Time at which we want to know particles positions
Time5=50000; %Time at which we want to know particles positions
Time6=100000; %Time at which we want to know particles positions


%measure concentration distribtion at time t=10;

Npart=1e3;
Nsteps=zeros(1,Npart);
x=Nsteps;
xold=Nsteps;
xnew=Nsteps;
told=Nsteps;
tnew=Nsteps;



for kk=1:Npart
kk
   t=0;
    
    while t<Time1
        told(kk)=t;
        tau=(1/(1-rand))^(1/alpha)*(alpha-1)/(alpha);
        tnew(kk)=told(kk)+tau;
        dtau(kk)=tau;
        t=tnew(kk);
        Nsteps(kk)=Nsteps(kk)+1;
        xold(kk)=x(kk);
        xnew(kk)=x(kk)+1;
        x(kk)=xnew(kk);
    end
    x1(kk)=x(kk);
    
    while t<Time2
        told(kk)=t;
        tau=(1/(1-rand))^(1/alpha)*(alpha-1)/(alpha);
        tnew(kk)=told(kk)+tau;
        dtau(kk)=tau;
        t=tnew(kk);
        Nsteps(kk)=Nsteps(kk)+1;
        xold(kk)=x(kk);
        xnew(kk)=x(kk)+1;
        x(kk)=xnew(kk);
    end
    x2(kk)=x(kk);
    
    while t<Time3
        told(kk)=t;
        tau=(1/(1-rand))^(1/alpha)*(alpha-1)/(alpha);
        tnew(kk)=told(kk)+tau;
        dtau(kk)=tau;
        t=tnew(kk);
        Nsteps(kk)=Nsteps(kk)+1;
        xold(kk)=x(kk);
        xnew(kk)=x(kk)+1;
        x(kk)=xnew(kk);
    end
    x3(kk)=x(kk);
    
    while t<Time4
        told(kk)=t;
        tau=(1/(1-rand))^(1/alpha)*(alpha-1)/(alpha);
        tnew(kk)=told(kk)+tau;
        dtau(kk)=tau;
        t=tnew(kk);
        Nsteps(kk)=Nsteps(kk)+1;
        xold(kk)=x(kk);
        xnew(kk)=x(kk)+1;
        x(kk)=xnew(kk);
    end    
    x4(kk)=x(kk);
    
    while t<Time5
        told(kk)=t;
        tau=(1/(1-rand))^(1/alpha)*(alpha-1)/(alpha);
        tnew(kk)=told(kk)+tau;
        dtau(kk)=tau;
        t=tnew(kk);
        Nsteps(kk)=Nsteps(kk)+1;
        xold(kk)=x(kk);
        xnew(kk)=x(kk)+1;
        x(kk)=xnew(kk);
    end
    x5(kk)=x(kk);
    
    while t<Time6
        told(kk)=t;
        tau=(1/(1-rand))^(1/alpha)*(alpha-1)/(alpha);
        tnew(kk)=told(kk)+tau;
        dtau(kk)=tau;
        t=tnew(kk);
        Nsteps(kk)=Nsteps(kk)+1;
        xold(kk)=x(kk);
        xnew(kk)=x(kk)+1;
        x(kk)=xnew(kk);
    end
    x6(kk)=x(kk);
    
    
end

%A few different Intepretatios of the Data

%Particles wait an then instantaneously jump to new position after a
%waiting time tau. Then the position of all particles xold describes their
%position at time 10

mu1=[mean(x1) mean(x2) mean(x3) mean(x4) mean(x5) mean(x6)];
time=[10 100 1000 10000 50000 100000];
figure(1)
plot(time,mu1)
figure(2)
mu2=[mean(x1.^2) mean(x2.^2) mean(x3.^2) mean(x4.^2) mean(x5.^2) mean(x6.^2)];
plot(time,mu2)
figure(1)
set(gca,'Xscale','log','Yscale','log')
figure(3)
plot(time,mu2-mu1.^2)
figure(3)
set(gca,'Xscale','log','Yscale','log')
