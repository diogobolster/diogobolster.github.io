%multiple_realizations.m

clear
clc
close all

Nreal=10;  %Number of realizations

for ll=1:Nreal
    
    rxnrw
    cd Mult_real
    eval(['save data_',num2str(ll),'.mat conc'])
    cd ..
end