%rxnrw.m

%clear;clc;close all

N=10000;  % Iintial Number of Particles
DA=5e-3;DB=5e-3;     %Diffusion coefficients of A and B
L=32;       %Length of the Domain
C0=4;       %Initial concentration
mp=C0*L/N;  %mass of each particle
k=0.5;      %reaction rate

dt=0.01;    %initial time step
epsilon=1+0.025;    %rate at which timestep is increased
dtmax=50;%8*pi*DA/k^2/mp^2/100;    %Maximum allowable timestep

x=L*rand(1,N);y=L*rand(1,N);  %initial distribution of A and B particles (x represent A, y B locations)

Nsteps=1e3;     %number of timesteps
conc=zeros(1,Nsteps);   %define concentration vector
conc(1)=length(x);      %initial concentration at t=0
time(1)=0;              %define time vector, initial t=0;

for kk=1:Nsteps
    kk
    
    dt=min(dt*epsilon,dtmax);   %define timestep allowing it to increase to a maximum
    Pr=k*mp*dt;     %probability of reaction
    
    %Random Walk part - update the location of particles x and y by a
    %Brownian motion

    x=x+sqrt(2*DA*dt)*randn(size(x));
    y=y+sqrt(2*DB*dt)*randn(size(y));
    
    %periodic elements - impose that any particle has left the domain
    %renters the periodic element on the other side
    apple=find(x>L);x(apple)=x(apple)-L;
    apple=find(y>L);y(apple)=y(apple)-L;
    apple=find(x<0);x(apple)=x(apple)+L;
    apple=find(y<0);y(apple)=y(apple)+L;
    
    %RXN
    
    xdead=zeros(size(x));   %tracker to kill of A particles that have reacted
    
    for jj=1:length(x)
       
        X=x(jj);
        
        %calculate minimum distance between this A and all B particles accounting for periodic
        %domain.
        s1=abs(X-y);    
        s2=abs(X-y+L);
        s3=abs(X-y-L);
        
        s=s1;
        apple=find(s2<s);
        s(apple)=s2(apple);
        apple=find(s3<s);
        s(apple)=s3(apple); %s is now the minimum distance between a particle pair
        
        %calculate the probability of reaction of each partile pair given
        %the distace between them
        Pf=Pr*1/sqrt(4*pi*(DA+DB)*dt)*exp(-s.^2/(4*(DA+DB)*dt)); 
       
        %generate a random number the size of each particle pair
        RP=Pf-rand(size(Pf));
        
        %identify the most probable of all possible reactions
        orange=find(RP==max(RP));
        
        %kill of the y particle that partook in the most probable reaction
        if(RP(orange)>0)
            xdead(jj)=1;
            y(orange)=[];
        end
    end
    
    %kill all particles that took place in a reaction
    apple=find(xdead==0);
    x=x(apple);
    
    %calculate the concentration in the domain at a given time
    conc(kk+1)=length(x);
    time(kk+1)=time(kk)+dt;
end

%renormalize concentration to 1 at t=0;
conc=conc/N;


%plot concentration against time

plot(time,conc,'m')
set(gca,'Xscale','log','Yscale','log')
hold on
plot(time,1./(1+k*C0*time),'r')
