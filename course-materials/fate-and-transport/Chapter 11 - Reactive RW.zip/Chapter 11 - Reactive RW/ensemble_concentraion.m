%ensemble_concentration.m

clear
clc
close all

cd Mult_real

Nreal=10; cens=zeros(1,1001); 
for ll=1:Nreal
    
    eval(['load data_',num2str(ll),'.mat conc'])
    cens=cens+conc;
end

cd ..

cens=cens/Nreal;

load time
plot(time,cens)
hold on
k=0.5; C0=4
plot(time,1./(1+k*C0*time),'r')
set(gca,'Xscale','log','Yscale','log')
xlabel('time')
ylabel('Concentration')
legend('C_{ensemble}','C_{beaker}')