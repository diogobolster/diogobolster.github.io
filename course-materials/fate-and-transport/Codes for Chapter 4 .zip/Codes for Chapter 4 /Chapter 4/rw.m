%rw.m

clear
clc
close all


dt=.01; %timestep
D=1;    %diffusion coefficient
N=1e6; % number of particles

xinit=0; %initial location of all the particles

x=xinit*ones(1,N);   %initial condition4
Nsteps=10;  %number of timesteps to go through

for kk=1:Nsteps
       
    x=x+sqrt(2*D*dt)*randn(size(x));    %update the particle postions following the Langevin equation for Brownian motion
    
end

[c,xx]=hist(x,100); %generate a histogram of the particle positions to generate concentration
dx=xx(2)-xx(1); %find the spatial step in the histogram (i.e. the size of the bin in which the number of particles are counted)
c=c/sum(c)/dx;  %normalize c to get the actual concentration field - here it is normalized so the total mass in the system is 1
plot(xx,c,'kd')
hold on

%Compare to an analytical solutiont=dt*Nsteps;
t=Nsteps*dt;    %the time at which the solution is to be calculated
canal=1/sqrt(4*pi*D*t)*exp(-xx.^2/(4*D*t)); %the analytical solution to the diffusion equation for a pulse initial condition
plot(xx,canal,'c')

%Now we will run the algoirth to greater points in time

Nsteps=50;

for kk=11:Nsteps
       
    x=x+sqrt(2*D*dt)*randn(size(x));
    
end

[c,xx]=hist(x,100);
dx=xx(2)-xx(1);
c=c/sum(c)/dx;
plot(xx,c,'kd')
hold on

%Compare to an analytical solutiont=dt*Nsteps;
t=Nsteps*dt;
canal=1/sqrt(4*pi*D*t)*exp(-xx.^2/(4*D*t));
plot(xx,canal,'c')


Nsteps=100;

for kk=51:Nsteps
       
    x=x+sqrt(2*D*dt)*randn(size(x));
    
end

[c,xx]=hist(x,100);
dx=xx(2)-xx(1);
c=c/sum(c)/dx;
plot(xx,c,'kd')
hold on

%Compare to an analytical solutiont=dt*Nsteps;
t=Nsteps*dt;
canal=1/sqrt(4*pi*D*t)*exp(-xx.^2/(4*D*t));
plot(xx,canal,'c')

Nsteps=200;

for kk=101:Nsteps
       
    x=x+sqrt(2*D*dt)*randn(size(x));
    
end

[c,xx]=hist(x,100);
dx=xx(2)-xx(1);
c=c/sum(c)/dx;
plot(xx,c,'kd')
hold on

%Compare to an analytical solutiont=dt*Nsteps;
t=Nsteps*dt;
canal=1/sqrt(4*pi*D*t)*exp(-xx.^2/(4*D*t));
plot(xx,canal,'c')
