%FD.m

clear
clc
close all

x=0:0.1:10;  %Define your spatial domain
dx=x(2)-x(1);  %spatial deicretization;
dt=0.001;        %time step
Nsteps=100000;    %Number of Timesteps
D=1;        %Diffusion Coefficient

C=zeros(size(x));  %Our Initial Concentration
C(1)=1;            %The Boundary Condition


for j=1:Nsteps

    %update concentration based no finite differences. We only update
    %locations 2 through N-1 as the end are determined from the boundary
    %conditions.
    
    Cnew(2:length(x)-1)=C(2:length(x)-1)+D*dt/dx^2*(C(1:length(x)-2)-2*C(2:length(x)-1)+C(3:length(x)));
    
    %Boundary Conditions
    Cnew(1)=1;
    Cnew(length(x))=0;
    
    %Update concentration field
    C=Cnew;
    
end

plot(x,C,'.')
hold on
%Greens function - finite domain.

n=1:1:10000; %number of terms in expansion

t=Nsteps*dt;
l=10;

for kk=1:length(x)
    
    sm=sin(n*pi*x(kk)/l).*l./n/pi.*(1-exp(-D*n.^2*pi^2*t/l^2));
    
    Cg(kk)=2/l*sum(sm);
    
end
Cg(1)=1;

hold on
plot(x,Cg,'rd')

%seminfite domain

Csm=erfc(x/sqrt(4*D*t));
plot(x,Csm,'g')