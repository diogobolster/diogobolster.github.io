% Example  - MIM

clear, close all

syms u alpha beta x s

% parameters 

u=1; 
alpha=1;
beta=1;
x=10;

% F(s) in symbolic form - the solution to be inverted from laplace space
F1=1/u*(exp(((-alpha*s - alpha*beta*s - beta*s^2)*x)/((alpha + beta*s)*u)));
% F(s) as a string
F1=char(F1);                     

%perform the inverse laplace transform
[t1,ft1]=INVLAP(F1,0.1,40,1000,6,20,19);

%F1 - function to be inverted
%0.1 - smallest time
%40 - largest time
%1000 - number of steps between 0.1 and 40
%last three are associated with method - keep the defaults for now.

plot(t1,ft1)