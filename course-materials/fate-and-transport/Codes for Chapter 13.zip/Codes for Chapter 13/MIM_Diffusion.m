% Example  - MIM

clear, close all

syms u alpha beta x s

% parameters 

time=5;
xplot=linspace(-10,10);

d=1; 
alpha=1;
beta=1;
j=1;
for x=xplot
    
    F1=(exp(-(abs(x)/sqrt(((d*(alpha+beta*s))/(s*(alpha+alpha*beta+beta*s))))))*sqrt((d*(alpha+beta*s))/(s*(alpha+alpha*beta+beta*s))))/(2*d);
    F1=char(F1);                     
    [t1,ft1]=INVLAP(F1,time,time,1,6,20,19);
    c(j)=ft1;
    j=j+1;
end
figure(1)
hold on
cdiffonly=1/sqrt(4*pi*d*time)*exp(-xplot.^2/4/d/time);
plot(xplot,cdiffonly,'r')
plot(xplot,c)

d=1; 
alpha=10;
beta=1;
j=1;
for x=xplot
    
    F1=(exp(-(abs(x)/sqrt(((d*(alpha+beta*s))/(s*(alpha+alpha*beta+beta*s))))))*sqrt((d*(alpha+beta*s))/(s*(alpha+alpha*beta+beta*s))))/(2*d);
    F1=char(F1);                     
    [t1,ft1]=INVLAP(F1,time,time,1,6,20,19);
    c(j)=ft1;
    j=j+1;
end
figure(1)
plot(xplot,c,'g')

d=1; 
alpha=1;
beta=10;
j=1;
for x=xplot
    
    F1=(exp(-(abs(x)/sqrt(((d*(alpha+beta*s))/(s*(alpha+alpha*beta+beta*s))))))*sqrt((d*(alpha+beta*s))/(s*(alpha+alpha*beta+beta*s))))/(2*d);
    F1=char(F1);                     
    [t1,ft1]=INVLAP(F1,time,time,1,6,20,19);
    c(j)=ft1;
    j=j+1;
end
figure(1)
plot(xplot,c,'m')

d=1; 
alpha=10;
beta=10;
j=1;
for x=xplot
    
    F1=(exp(-(abs(x)/sqrt(((d*(alpha+beta*s))/(s*(alpha+alpha*beta+beta*s))))))*sqrt((d*(alpha+beta*s))/(s*(alpha+alpha*beta+beta*s))))/(2*d);
    F1=char(F1);                     
    [t1,ft1]=INVLAP(F1,time,time,1,6,20,19);
    c(j)=ft1;
    j=j+1;
end
figure(1)
plot(xplot,c,'c')

legend('Only mobile','\alpha=1 \beta=1','\alpha=10 \beta=1','\alpha=1 \beta=10','\alpha=10 \beta=10')
title('Mobile Immobile Diffusion only D=1 at time=5')