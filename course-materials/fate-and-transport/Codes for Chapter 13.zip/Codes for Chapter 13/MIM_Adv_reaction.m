% Example  - MIM

clear, close all

syms u alpha beta x s

% parameters 

u=1; alpha=1;beta=1;x=10;

gamma=0;
F1=1/u*(exp(((-alpha*gamma-alpha*s - alpha*beta*s-gamma*s - beta*s^2)*x)/((alpha +gamma+ beta*s)*u)));
F1=char(F1);                     
[t1,ft1]=INVLAP(F1,0.1,40,1000,6,20,19);
hold on
plot(t1,ft1)

gamma=0.01;
F1=1/u*(exp(((-alpha*gamma-alpha*s - alpha*beta*s-gamma*s - beta*s^2)*x)/((alpha +gamma+ beta*s)*u)));
F1=char(F1);                     
[t1,ft1]=INVLAP(F1,0.1,40,1000,6,20,19);
hold on
plot(t1,ft1,'r')

gamma=0.1;
F1=1/u*(exp(((-alpha*gamma-alpha*s - alpha*beta*s-gamma*s - beta*s^2)*x)/((alpha +gamma+ beta*s)*u)));
F1=char(F1);                     
[t1,ft1]=INVLAP(F1,0.1,40,1000,6,20,19);
hold on
plot(t1,ft1,'g')

gamma=1;
F1=1/u*(exp(((-alpha*gamma-alpha*s - alpha*beta*s-gamma*s - beta*s^2)*x)/((alpha +gamma+ beta*s)*u)));
F1=char(F1);                     
[t1,ft1]=INVLAP(F1,0.1,40,1000,6,20,19);
hold on
plot(t1,ft1,'k')

legend('\gamma=0','\gamma=0.01','\gamma=0.1','\gamma=1')
title('BTC Advection Mobile (u=1,\alpha=1,\beta=1,x=10), Reaction Immobile different \gamma')