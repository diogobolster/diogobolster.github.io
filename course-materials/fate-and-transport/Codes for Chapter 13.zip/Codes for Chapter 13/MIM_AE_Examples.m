% Example  - MIM

clear, close all

syms u alpha beta x s

% parameters 

u=1; alpha=1; beta=1;x=10;
F1=1/u*(exp(((-alpha*s - alpha*beta*s - beta*s^2)*x)/((alpha + beta*s)*u)));
F1=char(F1);                     

u=1; alpha=10; beta=1;x=10;
F2=1/u*(exp(((-alpha*s - alpha*beta*s - beta*s^2)*x)/((alpha + beta*s)*u)));
F2=char(F2);                     

u=1; alpha=1; beta=10;x=10;
F3=1/u*(exp(((-alpha*s - alpha*beta*s - beta*s^2)*x)/((alpha + beta*s)*u)));
F3=char(F3);                     

u=1; alpha=10; beta=10;x=10;
F4=1/u*(exp(((-alpha*s - alpha*beta*s - beta*s^2)*x)/((alpha + beta*s)*u)));
F4=char(F4);                     

%perform the inverse laplace transform
[t1,ft1]=INVLAP(F1,0.1,40,1000,6,20,19);
[t2,ft2]=INVLAP(F2,0.1,40,1000,6,20,19);
[t3,ft3]=INVLAP(F3,0.1,400,1000,6,20,19);
[t4,ft4]=INVLAP(F4,0.1,400,1000,6,20,19);

figure(1)
subplot(2,2,1)
plot(t1,ft1)
xlabel('Time')
ylabel('Concentration')
title('x=10 \alpha=1 \beta=1')

subplot(2,2,2)
plot(t2,ft2)
xlabel('Time')
ylabel('Concentration')
title('x=10 \alpha=10 \beta=1')

subplot(2,2,3)
plot(t3,ft3)
xlabel('Time')
ylabel('Concentration')
title('x=10 \alpha=1 \beta=10')

subplot(2,2,4)
plot(t4,ft4)
xlabel('Time')
ylabel('Concentration')
title('x=10 \alpha=10 \beta=10')