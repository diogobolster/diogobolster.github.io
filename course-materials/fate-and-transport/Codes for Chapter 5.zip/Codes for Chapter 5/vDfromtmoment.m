%vdfromtmoment.m

clear
%clc
close all

x=100;

load data_tmoment

plot(t,c)
figure(1)
xlabel('time(s)')
ylabel('Concentration (kg/m)')

m0=sum(c*dt);

v=1/m0

m1=sum(t.*c*dt);

D=1/2*(m1*v^3-v*x)


%least squares fit

vD = lsqcurvefit(@(vD,t) 1./sqrt(4*pi*vD(2)*t).*exp(-(x-vD(1)*t).^2./(4*D*t)),[0.2 0.1],t,c)
