%Horton_infiltration

%This code solves the example Horton infltration model in the class notes

%Begin by clearing the computer memory
clear
close all
clc

%Discretize time over the 5 hours of interest

t=0:0.01:5; %here I am breaking the 5 hours into increments of 0.01 hrs


% We consider three different precipitation events, defined by a case number (1,2,3)

setup=3;


%Parameters associated with the Horton Infiltration Capacity Model
fc=10;
fo=120;
k=1/2;

% Calculate the Horton Infiltration Capacity over the time of interest
I=fc+(fo-fc)*exp(-k*t);

%Plot the Horton Infiltration Capacity
plot(t,I,'LineWidth',2)
set(gca,'FontSize',16)
xlabel('Time (hr)','FontSize',16)
ylabel('Infiltration (mm/hr)','FontSize',16)

pause

%Now we will plot the precipitation on the same plot - different for each
%case

%Precipitation setup 1
if setup==1
    II=ones(size(t))*25;
    hold on
    plot(t,II,'r','LineWidth',2)
end

%Precipitation setup 2
if setup==2
    II(1:100)=25;
    II(101:300)=10;
    II(301:501)=50;
    hold on
    plot(t,II,'r','LineWidth',2)
end

%Precipitation setup 3
if setup==3
    II(1:100)=50;
    II(101:300)=25;
    II(301:501)=10;
    hold on
    plot(t,II,'r','LineWidth',2)
end

pause

%Now find the minimum of Infiltration Capacity (I) and Precipitation (II) at each point in time

apple=find(II<I)	%Here we we finding the elements in the vectore where II<I
Infiltration=I;		%Assume Infiltration rate is given by I, the Horton Infiltration Capacity
Infiltration(apple)=II(apple);	%Now replace all elements with those of II, where II<I



%Plot this minimum of I and II to verify that it is indeed correct
plot(t,Infiltration,'g*')


%Now to get the total infiltration we have to integrate this over the whole time, by using a simple numerical integration.

dt=t(2)-t(1);		%size of the time step
Total_I=sum(Infiltration*dt)		%Simple integration scheme
