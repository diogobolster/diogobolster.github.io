%draw_ADE_dirac.m

clear
clc
close all

t2=linspace(1,1e7,1e6);
t1=linspace(1,1e5,1e3);
x1=-2;
x2=500;
count=1;

        Dm=1e-9;  %diffusion coefficient
        alpha=0.01; %dispersivity
        v=500/90*1/24*1/3600;    %velocity
        D=Dm+alpha*v;
        c1=1./sqrt(4*pi*D*t1).*exp(-(x1-v*t1).^2./(4*D*t1));
        c2=2./sqrt(4*pi*D*t2).*exp(-(x2-v*t2).^2./(4*D*t2));
        subplot(2,1,1)
        plot(t1,c1,'k','Linewidth',1)
        subplot(2,1,2)
        plot(t2,c2,'r','Linewidth',1)
        
ylabel('Concentration')
xlabel('t')
