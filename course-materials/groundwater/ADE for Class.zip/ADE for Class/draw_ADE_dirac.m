%draw_ADE_dirac.m

clear
clc
close all

t=1;  %time
Dm=1;  %diffusion coefficient
alpha=1; %dispersivity
v=1;    %velocity

D=Dm+alpha*v;


x=linspace(-25,25,1000);



c=1./sqrt(4*pi*D*t)*exp(-(x-v*t).^2./(4*D*t));


plot(x,c,'k','Linewidth',2)

ylabel('Concentration')
xlabel('x')
