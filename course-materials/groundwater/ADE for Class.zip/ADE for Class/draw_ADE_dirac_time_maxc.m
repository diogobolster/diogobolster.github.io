%draw_ADE_dirac.m

clear
clc
close all

x=linspace(-30,200,1000);  %spatial domain
count=1;

 for t=0.1:0.1:100 ;  %time
        Dm=1;  %diffusion coefficient
        alpha=1; %dispersivity
        v=1;    %velocity
        D=Dm+alpha*v;
        c=1./sqrt(4*pi*D*t)*exp(-(x-v*t).^2./(4*D*t));
        apple=find(c==max(c));
        plot(x,c,'k','Linewidth',1)
        hold on
        plot(x(apple),c(apple),'g.')
 end

ylabel('Concentration')
xlabel('x')
