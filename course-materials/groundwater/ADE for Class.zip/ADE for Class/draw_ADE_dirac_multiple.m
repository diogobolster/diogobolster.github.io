%draw_ADE_dirac.m

clear
clc
close all

x=linspace(-30,30,1000);  %spatial domain

t=1;  %time
Dm=1;  %diffusion coefficient
alpha=1; %dispersivity
v=1;    %velocity
D=Dm+alpha*v;
c=1./sqrt(4*pi*D*t)*exp(-(x-v*t).^2./(4*D*t));
plot(x,c,'k','Linewidth',2)


hold on

t=10;  %time
Dm=1;  %diffusion coefficient
alpha=1; %dispersivity
v=1;    %velocity
D=Dm+alpha*v;
c=1./sqrt(4*pi*D*t)*exp(-(x-v*t).^2./(4*D*t));
plot(x,c,'r','Linewidth',2)


t=1;  %time
Dm=10;  %diffusion coefficient
alpha=1; %dispersivity
v=1;    %velocity
D=Dm+alpha*v;
c=1./sqrt(4*pi*D*t)*exp(-(x-v*t).^2./(4*D*t));
plot(x,c,'g','Linewidth',2)

t=1;  %time
Dm=1;  %diffusion coefficient
alpha=10; %dispersivity
v=1;    %velocity
D=Dm+alpha*v;
c=1./sqrt(4*pi*D*t)*exp(-(x-v*t).^2./(4*D*t));
plot(x,c,'c','Linewidth',2)


t=1;  %time
Dm=1;  %diffusion coefficient
alpha=1; %dispersivity
v=10;    %velocity
D=Dm+alpha*v;
c=1./sqrt(4*pi*D*t)*exp(-(x-v*t).^2./(4*D*t));
plot(x,c,'m','Linewidth',2)

ylabel('Concentration')
xlabel('x')

