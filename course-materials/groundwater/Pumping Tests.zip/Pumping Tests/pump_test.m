%pump_test

clear
clc
close all

load data.mat

figure(1)
%subplot(3,1,1)
hold on
plot(t,s,'.')
xlabel('Time t')
ylabel('Drawdown s')


pause

%subplot(3,1,2)
figure(2)
hold on
plot(t,s,'.')
set(gca,'Xscale','log')

xlabel('Time t')
ylabel('Drawdown s')

pause

figure(3)
%subplot(3,1,3)
hold on
plot(t,s,'.')

xlabel('Time t')
ylabel('Drawdown s')
set(gca,'Yscale','log')
set(gca,'Xscale','log')

pause

figure(4)
hold on
plot(t,s,'.')
plot(t,ss,'r')
set(gca,'Xscale','log')
axis([1e-1 1e3 -1 6])
xlabel('Time t')
ylabel('Drawdown s')
plot([1e-1 1e3],[0 0],'k')

pause

u(1)=0.0001;

for ii=2:120
    u(ii)=u(ii-1)*1.1;
    u(ii);
end


W=expint(u);

figure(10)
hold on
plot(1./u,W,'.')
 
xlabel('1/u')
ylabel('W')
set(gca,'Yscale','log')
set(gca,'Xscale','log')
grid

pause

figure(11)
hold on
plot(1./u,W,'.')

xlabel('1/u')
ylabel('W')
set(gca,'Yscale','log')
set(gca,'Xscale','log')
grid
axis([0.1 1e4 0.01 1e1])
hold on

plot(t,s,'r')

pause

figure(12)
hold on
plot(1./u,W,'.')

xlabel('1/u')
ylabel('W')
set(gca,'Yscale','log')
set(gca,'Xscale','log')
grid
axis([0.1 1e4 0.01 1e1])
hold on

plot(t*3.5,1.2*s,'r')

%plot(4.0*t,1.25*s,'r')

% figure(20)
% hl1 = line(1./u,W,'Color','r');
% ax1 = gca;
% 
% ax2 = axes('Position',get(ax1,'Position'),...
%            'XAxisLocation','top',...
%            'YAxisLocation','right',...
%            'Color','none',...
%            'XColor','k','YColor','k');
%        
% hl2 = line(100*t,s,'Color','k','Parent',ax2);       
% 
% set(ax1,'Yscale','log')
% set(ax1,'Xscale','log')
% set(ax2,'Yscale','log')
% set(ax2,'Xscale','log')
