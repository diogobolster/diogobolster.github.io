%well_function.m

clear
clc
close all

u(1)=0.0001;

for ii=2:120
    u(ii)=u(ii-1)*1.1;
    u(ii)
end


W=expint(u);


figure(1)
hold on
plot(1./u,W,'.')

xlabel('1/u')
ylabel('W')
set(gca,'Yscale','log')
set(gca,'Xscale','log')
grid
axis([0.1 1e4 0.01 1e1])