%CBP.m

clear
clc
close all

t=[0.01 0.05 0.1 0.2 0.5 1 5 10 20];
hho=[96.5 86 74.5 58 29 10.8 6.2 2.7 1.3]/100;

figure(1)
plot(t,hho,'.')
hold on
plot(t,hho,'k-','Linewidth',2.5)
set(gca,'Xscale','log')
xlabel('Time(s)')
ylabel('H/H_0')


figure(2)
plot(t,hho,'.')
hold on
plot(t,hho,'k-','Linewidth',2.5)
set(gca,'Xscale','log')
xlabel('Time(s)')
ylabel('H/H_0')
axis([1e-3 1e2 0 1])
%plot data from CBP paper (Table in HW 4)
eta=[0.1 0.5 1 2 5 10 50 100 200];
hho=[96.5 86 74.5 58 29 10.8 6.2 2.7 1.3]/100;
plot(eta,hho,'r.')
set(gca,'Xscale','log')
xlabel('eta')
ylabel('H/H_0')

figure(3)
plot(10*t,hho,'.')
hold on
plot(10*t,hho,'k-','Linewidth',2.5)
set(gca,'Xscale','log')
xlabel('Time(s)')
ylabel('H/H_0')
axis([1e-3 1e2 0 1])
%plot data from CBP paper (Table in HW 4)
eta=[0.1 0.5 1 2 5 10 50 100 200];
hho=[96.5 86 74.5 58 29 10.8 6.2 2.7 1.3]/100;
plot(eta,hho,'r.')
set(gca,'Xscale','log')
xlabel('eta')
ylabel('H/H_0')