clear
clc
close all

t=[0.5 1 2 4 5 7 8 9];
h=[0.9 0.82 0.67 0.37 0.25 0.2 0.165 0.135];

figure(1)
plot(t,h)
hold on
plot(t,h,'.')
axis([0 10 0 1])

figure(2)
plot(t,h)
hold on
plot([0 10], [0.37 0.37],'r') 
xlabel('t(s)')
ylabel('H/H0')
axis([0 10 0 1])
