function dydt = exode45(t,y)
dydt = [-0.1*y(1)+0.2*y(2); +0.1*y(1)-0.2*y(2) ];