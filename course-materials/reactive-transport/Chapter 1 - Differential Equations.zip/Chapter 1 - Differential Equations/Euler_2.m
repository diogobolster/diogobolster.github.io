clear; clc; close all

dt=0.01; %size of the my time step
Nsteps=10000;  %Number of time steps I will take
C1(1)=1;        %initial concentration of C1
C2(1)=1;        %initial concentration of C2
C3(1)=2;        %initial concentration of C2
time(1)=0;      %initial time

for kk=1:Nsteps   
    C1(kk+1)=C1(kk)+dt*(-0.2*C1(kk)+0.3*C2(kk));  %update concentration 1
    C2(kk+1)=C2(kk)+dt*(0.2*C1(kk)-0.4*C2(kk)+0.1*C3(kk));   %update concentration 2
    C3(kk+1)=C3(kk)+dt*(0.1*C2(kk)-0.1*C3(kk));   %update concentration 2
    time(kk+1)=time(kk)+dt;                         %update time
end

plot(time,C1,'b')
hold on
plot(time,C2,'r')
plot(time,C3,'g')
xlabel('time')
ylabel('Concentration')
legend('C1','C2')
%axis([0 100 0 1])


