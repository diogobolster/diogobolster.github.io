clear
clc
close all

%this is the very last problem in chpater 1

D=1e-2;  %total dispersion coefficient
v=1;    % velocity
t=1;    %time
x=linspace(-10,15,1000);  %Define the range of x over which I will plot things

M1=3;
M2=5;
M3=4;

C1=M1/2*(erfc((x-10-v*t)/sqrt(4*D*t))-erfc((x-5-v*t)/sqrt(4*D*t)));
C2=M2/2*(erfc((x+5-v*t)/sqrt(4*D*t))-erfc((x+10-v*t)/sqrt(4*D*t)))
C3=M3/2*(erfc((x-3-v*t)/sqrt(4*D*t))-erfc((x+3-v*t)/sqrt(4*D*t)))

C=C1+C2+C3;
figure(1)
plot(x,C)