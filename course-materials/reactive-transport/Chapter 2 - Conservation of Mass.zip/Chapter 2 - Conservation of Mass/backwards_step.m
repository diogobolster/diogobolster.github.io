%backwards_step.m

clear; clc; close all

x=linspace(-20,60,1000);

time=linspace(eps,40,100);

C0=1;
v=1;
D=.5;

count=1;

for kk=time
    
    C=C0/2*(erfc((x-v*kk)/sqrt(4*D*kk)));
    figure(1)
    plot(x,C)
    axis([-15 55 -0.1 1.1])
    pause(0.01)
    
    M(count) = getframe;
    count=count+1;
end
