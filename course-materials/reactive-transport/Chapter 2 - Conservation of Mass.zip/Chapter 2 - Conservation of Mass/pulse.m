%pulse.m

clear; clc; close all

x=linspace(-20,60,1000);

time=linspace(eps,40,100);

C0=1;
v=1;
D=.1;

count=1;
for tt=time
    
    C=1/sqrt(4*pi*D*tt)*exp(-(x-v*tt).^2/(4*D*tt));
    figure(1)
    plot(x,C)
    axis([-15 55 -0.1 1.1])
    pause(0.01);
    
    M(count) = getframe;
    count=count+1;
    
end
