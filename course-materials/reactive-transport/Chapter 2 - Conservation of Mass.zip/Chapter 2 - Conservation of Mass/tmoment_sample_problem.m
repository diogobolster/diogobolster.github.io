clear
clc
close all

%This loads the data for the Breakthrough Curve for the Sample Problem from
%class

%c is the concentration
%t is time

load data_tmoment

plot(t,c) %plot to verify that the data is the same as that in class example
xlabel('time')
ylabel('Concentration')

%we will now calculate a numerical approximation of the integrals required
%for the moments

%For this I need to know the time steps;

dt=t(2)-t(1);

%zeroth moment - int c dt = sum c \delta t

M0=sum(c*dt)

%first moment - int c*t dt = sum c*t \delta t

M1=sum(c.*t*dt)