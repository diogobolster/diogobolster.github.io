clear;clc;close all

%empirical river example from class

load data_river


%We are going to fit a power law Y=aX^b. To do this fit log of X
%against the log of Y, because log(Y)=log(a) + b*log(X)

P=polyfit(log(X),log(Y),1);

%Now a=exp(P(2)) and b=P(1)

a=exp(P(2))
b=P(1)

%check the goodness of your fit

plot(X,Y,'o') %original data
x=linspace(min(X),max(X));
y=a*x.^b;
hold on
plot(x,y,'r')

set(gca,'Xscale','log','Yscale','log')
xlabel('Discharge in Cubic Meters per Second')
ylabel('Suspended Semimat Load (tons per day)')
