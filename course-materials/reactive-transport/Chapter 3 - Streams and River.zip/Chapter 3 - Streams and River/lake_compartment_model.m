%lake model

%Here we solve the sample problem from class where we describe the
%distribution of contaminants in a lake using a three compartment model

clear;clc; close all

V1=500; V2=250; V3=250; %volumes of the reservoirs

c1=0;c2=0;c3=0; %the lake starts as pristine
time=0; %time starts at zero;
dt=0.01; %time step

Qsw=20; %surface water flux
Csw=5;  %surface water concentration

Qgw=2; %grounwater flux into middle and bottom layer - in this case they are equal

Q12=5; %exchange rate between layer 1 and 2
Q23=1; %Exchange rate between layer 2 and 3

Nsteps=1e5; %number of time staps

for kk=1:Nsteps
    
    c1(kk+1)=c1(kk)+dt*(1/V1)*(100-25*c1(kk)+5*c2(kk));
    c2(kk+1)=c2(kk)+dt*(1/V2)*(5*c1(kk)-8*c2(kk)+c3(kk));    
    c3(kk+1)=c3(kk)+dt*(1/V3)*(c2(kk)-3*c3(kk));    
    time(kk+1)=time(kk)+dt;
end

figure(1)
hold on
plot(time,c1,'k')
plot(time,c2,'r')
plot(time,c3,'m')
xlabel('time')
ylabel('Concentration')
legend('C_1','C_2','C_3')
    
    