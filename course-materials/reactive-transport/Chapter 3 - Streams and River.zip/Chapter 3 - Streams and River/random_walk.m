clear
clc
close all

N=1e4;

x=zeros(1,N);
y=linspace(-1,0,N);

dt=1e-2;
D=0.01;

Nsteps=3e4;
count=1;

for kk=1:Nsteps

    
    x=x+(1-y.^2)*dt+sqrt(2*D*dt)*randn(size(x));
    y=y+sqrt(2*D*dt)*randn(size(y));
    
    apple=find(y>0);
    y(apple)=-y(apple);
    
    apple=find(y<-1);
    y(apple)=-2-y(apple);
    
    if mod(kk,200)==0
       
       figure(1)
       hold off 
       plot(x,y,'.')
       hold on
       xb=[0 20];
       yb=[0 0];
       plot(xb,yb,'k')
       yb=[-1 -1];
       plot(xb,yb,'k') 
       axis([mean(x)-50 mean(x)+50 -1 0])
       daspect([10 1 1])
       pause(0.01)
      
       M(count) = getframe;
       count=count+1;
      
    end
    
    
    
end
