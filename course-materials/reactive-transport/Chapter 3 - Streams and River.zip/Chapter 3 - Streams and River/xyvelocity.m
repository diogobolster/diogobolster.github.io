clear
clc
close all

y=linspace(-1,1);
u= 1-y.^20;
figure(1)
plot(u,y,'m--')
hold on
plot([-1 3],[-1 -1],'k')
plot([-1 3],[1 1],'k')
axis([-0.5 1.5 -1.5 1.5])
set(gca,'XTick',[],'YTick',[])


figure(2)
hold on
z=linspace(0,1);
u=log(z/0.01);
plot(u,z,'m--')

plot([-1 6],[1 1],'k--')
plot([-1 6],[0 0],'k')
axis([-0.5 5 -0.5 1.5])
set(gca,'XTick',[],'YTick',[])
daspect([4 1 1])


