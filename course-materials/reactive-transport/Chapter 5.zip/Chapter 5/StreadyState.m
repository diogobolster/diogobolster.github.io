clear
clc
close all

u=0.01;  %velocity
alpha_L=1; %longitudinal dispersion
alpha_T=alpha_L/10;
C0=1;
L=1; %total width of contamination zone
gam=0.10;
t=10;

x=0:0.01:2;
y=-L:0.01:L;

[X,Y]=meshgrid(x,y);

C1=C0/4 .*exp(X/2/alpha_L*(1-sqrt((u+4*gam*alpha_L)/u)));
C2=erfc((X-u*t*sqrt((u+4*gam*alpha_L)/u))/2/sqrt(alpha_L*u*t));
C3=erf((Y+L/2)./2./sqrt(alpha_T*X))-erf((Y-L/2)./2./sqrt(alpha_T*X));

C=C1.*C2.*C3;

pcolor(X,Y,C)
shading interp
daspect([1 1 1])
colorbar
