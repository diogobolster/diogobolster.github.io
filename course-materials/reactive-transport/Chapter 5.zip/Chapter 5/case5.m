clear
clc
close all

R=1;
u=10;
alpha_L=1;
Dm=1e-5;
t=10;
xprime=0;
yprime=0;

alpha_T=alpha_L/10;


Dx=Dm+alpha_L*u;
Dy=Dm+alpha_T*u;

x=60:0.1:140;
y=-20:0.1:20;

[X,Y]=meshgrid(x,y);

C=1/(4*pi*t/R*sqrt(Dx*Dy))*exp(-(X-xprime-u*t/R).^2/(4*Dx*t/R)-(Y-yprime).^2/(4*Dy*t/R));

pcolor(X,Y,C)
shading interp
daspect([1 1 1])
colorbar