clear
clc
close all

R=1;
u=1;
alpha_L=0.1;
Dm=1e-5;
t=10;
xprime=0;
yprime=0;

alpha_T=alpha_L/10;


Dx=Dm+alpha_L*u;
Dy=Dm+alpha_T*u;

x=0:0.1:20;
y=-5:0.1:5;

[X,Y]=meshgrid(x,y);

C=1/(4*pi*t/R*sqrt(Dx*Dy))*exp(-(X-xprime-u*t/R).^2/(4*Dx*t/R)-(Y-yprime).^2/(4*Dy*t/R));

pcolor(X,Y,C)
shading interp
daspect([1 1 1])
colorbar