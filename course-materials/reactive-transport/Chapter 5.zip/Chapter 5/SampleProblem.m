clear
clc
close all

u=8;  %velocity
alpha_L=0.01; %longitudinal dispersion
alpha_T=alpha_L/10;
C0=5;
L=50; %total width of contamination zone
gam=0;

X=0:1e11:5e15;
Y=0;

C1=C0/4 .*exp(X/2/alpha_L*(1-sqrt((u+4*gam*alpha_L)/u)));
C2=2;
C3=erf((Y+L/2)./2./sqrt(alpha_T*X))-erf((Y-L/2)./2./sqrt(alpha_T*X));

C=C1.*C2.*C3;

figure(1)
plot(X,C)
set(gca,'Xscale','log','Yscale','log')

pause

clear
clc
close all

u=8;  %velocity
alpha_L=0.01; %longitudinal dispersion
alpha_T=alpha_L/10;
C0=5;
L=50; %total width of contamination zone
gam=0:0.0001:0.02;

X=5000;
Y=0;

C1=C0/4 .*exp(X/2/alpha_L*(1-sqrt((u+4*gam*alpha_L)/u)));
C2=2;
C3=erf((Y+L/2)./2./sqrt(alpha_T*X))-erf((Y-L/2)./2./sqrt(alpha_T*X));

C=C1.*C2.*C3;

figure(1)
plot(gam,C)
set(gca,'Xscale','log','Yscale','log')