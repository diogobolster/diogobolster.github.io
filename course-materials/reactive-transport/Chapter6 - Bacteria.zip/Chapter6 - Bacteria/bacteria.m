clear
clc
close all

%these are just some random numbers I picked corresponding to the
%parameters in the powerpoint

kd=1; %death rate
K=1000; %carrying capacity
alpha=10; %growth rate
G=900; % half rate concentration
u=1;  %advection velocity
Y=1;  %Specific yield

S(1)=1000;
dx=1e-3;

Nx=1e4;

for kk=1:Nx
   
    S(kk+1)=S(kk)+dx*K*kd *(G*kd + (-alpha + kd)*S(kk))/(alpha*u*Y*S(kk));
    
end

x=0:dx:Nx*dx;

plot(x,S)

xlabel('x')
ylabel('Concentration')
